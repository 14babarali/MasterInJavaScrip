# 10 Framework Comparsion

Build a simple todo app with...

1. Vanilla JS
1. React
1. Angular
1. Vue
1. Svelte 
1. Lit
1. Alpine
1. Solid
1. Stencil
1. Mithril

Watch the full [JS framework comparison](https://youtu.be/cuHDQhDhvPE) on YouTube
