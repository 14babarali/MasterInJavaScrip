import { LitApp } from './src/LitApp.js';

window.customElements.define('lit-app', LitApp);
