const HashSet = require('./hash-set');

module.exports = HashSet;
