/**
 * Simple node of a Linked List
 */
class Node {
  constructor(value) {
    this.value = value;
    this.next = null;
  }
}

module.exports = Node;
