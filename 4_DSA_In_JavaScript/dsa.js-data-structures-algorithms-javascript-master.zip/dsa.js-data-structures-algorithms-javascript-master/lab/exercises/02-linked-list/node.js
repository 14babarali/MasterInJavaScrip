class Node {
  constructor(data) {
    this.data = data;
  }
}

module.exports = Node;