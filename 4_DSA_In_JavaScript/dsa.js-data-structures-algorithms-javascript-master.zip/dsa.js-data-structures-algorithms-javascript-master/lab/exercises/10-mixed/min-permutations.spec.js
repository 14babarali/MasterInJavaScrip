const fn = require('./min-permutations');

describe('Min Permutations', () => {
  it('should work', () => {
    expect(fn([1,2,3])).toEqual();
  });
});
