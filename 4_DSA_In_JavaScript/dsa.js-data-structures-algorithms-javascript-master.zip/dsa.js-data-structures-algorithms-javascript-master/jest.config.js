module.exports = {
  name: 'dsa.js',
  testPathIgnorePatterns: ['/node_modules/', '/dist/', '/lab/', '/benchmarks/', '/coverage/'],
};
