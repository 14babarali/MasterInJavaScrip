module.exports.databaseOptions = {
    host     : 'localhost',
    user     : 'root',
    password : 'Test123',
    database : 'test',
   // demo     : 'http://www.webdriveruniversity.com/',
    demo     : 'http://www.webdriveruniversity.com/Contact-Us/contactus.html'
   //Updated
  }

