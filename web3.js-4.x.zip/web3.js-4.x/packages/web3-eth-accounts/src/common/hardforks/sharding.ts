export default {
	"name": "shardingFork",
	"comment": "Internal hardfork to test proto-danksharding (do not use in production)",
	"url": "https://eips.ethereum.org/EIPS/eip-4844",
	"status": "Experimental",
	"eips": [4844]
}
 ;